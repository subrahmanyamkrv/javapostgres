package com.oati.evms.service;

import org.springframework.stereotype.Service;

@Service
public interface ElectricVehicleService {
	/**
	 * Used to build electric vehicle Object and save to MongoDB
	 * 
	 * @param inputPath
	 * @param outputPath
	 */
	public void BuildElectricVehicles(String inputPath, String outputPath);

}
