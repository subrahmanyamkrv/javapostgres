package com.oati.evms.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.oati.evms.model.ElectricVehicle;

/**
 * This class is used to find the vehicles from the MongoDB
 * 
 * @author venkatas
 *
 */
@Repository
public interface ElectricVehicleRepository extends MongoRepository<ElectricVehicle, String> {

	@Query("{vehicleId:{$regex :'^?0$', $options: 'i'}}")
	ElectricVehicle findVehicleById(String vehicleId);

}
