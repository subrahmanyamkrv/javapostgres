/**
 * 
 */
package com.oati.evms.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.stereotype.Component;

/**
 * Used to represent the ElectricVehicle in MongoDB
 * 
 * @author raghavendrar
 *
 */

@Component
@Document(collection = "electricVehicles")
public class ElectricVehicle {

	@Id
	private String id;

	/**
	 * 
	 * @return id
	 */
	public String getId() {
		return id;
	}

	/**
	 * 
	 * @param id
	 *            to set id
	 */
	public void setId(String id) {
		this.id = id;
	}

	private String vehicleId;
	private String make;
	private String model;
	private String year;
	private String color;
	private String batteryCapacity;
	private String plugType;
	private String style;
	private String range;
	private String homeChargingSpeed;
	private String fastChargingTime;
	private String fastChargingThreshold;

	/**
	 * 
	 * @return range
	 */
	public String getRange() {
		return range;
	}

	/**
	 * 
	 * @param range
	 *            to set range
	 */
	public void setRange(String range) {
		this.range = range;
	}

	/**
	 * 
	 * @return homeChargingSpeed
	 */
	public String getHomeChargingSpeed() {
		return homeChargingSpeed;
	}

	/**
	 * 
	 * @param homeChargingSpeed
	 *            to set homeChargingSpeed
	 */
	public void setHomeChargingSpeed(String homeChargingSpeed) {
		this.homeChargingSpeed = homeChargingSpeed;
	}

	/**
	 * 
	 * @return fastChargingTime
	 */
	public String getFastChargingTime() {
		return fastChargingTime;
	}

	/**
	 * 
	 * @param fastChargingTime
	 *            to set fastChargingTime
	 */
	public void setFastChargingTime(String fastChargingTime) {
		this.fastChargingTime = fastChargingTime;
	}

	/**
	 * 
	 * @return fastChargingThreshold
	 */
	public String getFastChargingThreshold() {
		return fastChargingThreshold;
	}

	/**
	 * 
	 * @param fastChargingThreshold
	 *            to set fastChargingThreshold
	 */
	public void setFastChargingThreshold(String fastChargingThreshold) {
		this.fastChargingThreshold = fastChargingThreshold;
	}

	/**
	 * 
	 * @return vehicleId
	 */
	public String getVehicleId() {
		return vehicleId;
	}

	/**
	 * 
	 * @param vehicleId
	 *            to set vehicleId
	 */
	public void setVehicleId(String vehicleId) {
		this.vehicleId = vehicleId;
	}

	/**
	 * 
	 * @return make
	 */
	public String getMake() {
		return make;
	}

	/**
	 * 
	 * @param make
	 *            to set make
	 */
	public void setMake(String make) {
		this.make = make;
	}

	/**
	 * 
	 * @return model
	 */
	public String getModel() {
		return model;
	}

	/**
	 * 
	 * @param model
	 *            to set model
	 */
	public void setModel(String model) {
		this.model = model;
	}

	/**
	 * 
	 * @return year
	 */
	public String getYear() {
		return year;
	}

	/**
	 * 
	 * @param year
	 *            to set year
	 */
	public void setYear(String year) {
		this.year = year;
	}

	/**
	 * 
	 * @return color
	 */
	public String getColor() {
		return color;
	}

	/**
	 * 
	 * @param color
	 *            to set color
	 */
	public void setColor(String color) {
		this.color = color;
	}

	/**
	 * 
	 * @return batteryCapacity
	 */
	public String getBatteryCapacity() {
		return batteryCapacity;
	}

	/**
	 * 
	 * @param batteryCapacity
	 *            to set batteryCapacity
	 */
	public void setBatteryCapacity(String batteryCapacity) {
		this.batteryCapacity = batteryCapacity;
	}

	/**
	 * 
	 * @return plugType
	 */
	public String getPlugType() {
		return plugType;
	}

	/**
	 * 
	 * @param plugType
	 *            to set plugType
	 */
	public void setPlugType(String plugType) {
		this.plugType = plugType;
	}

	/**
	 * 
	 * @return style
	 */
	public String getStyle() {
		return style;
	}

	/**
	 * 
	 * @param style
	 *            to set style
	 */
	public void setStyle(String style) {
		this.style = style;
	}

}
