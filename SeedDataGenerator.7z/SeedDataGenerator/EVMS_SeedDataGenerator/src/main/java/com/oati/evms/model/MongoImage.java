package com.oati.evms.model;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.stereotype.Component;
import org.threeten.bp.OffsetDateTime;

/**
 * Used to represent the Images in MongoDB
 * 
 * @author venkatas
 *
 */
@Component
@Document(collection = "Images")
public class MongoImage {

	private String objectId;
	private String objecttype;
	private String imagetype;
	private String image;
	private String format;
	private OffsetDateTime timeStamp;

	/**
	 * 
	 * @return objectId
	 */
	public String getObjectId() {
		return objectId;
	}

	/**
	 * 
	 * @param objectId
	 *            to set objectId
	 */
	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}

	/**
	 * 
	 * @return objecttype
	 */
	public String getObjecttype() {
		return objecttype;
	}

	/**
	 * 
	 * @param objecttype
	 *            to set objecttype
	 */
	public void setObjecttype(String objecttype) {
		this.objecttype = objecttype;
	}

	/**
	 * 
	 * @return imagetype
	 */
	public String getImagetype() {
		return imagetype;
	}

	/**
	 * 
	 * @param imagetype
	 *            to set imagetype
	 */
	public void setImagetype(String imagetype) {
		this.imagetype = imagetype;
	}

	/**
	 * 
	 * @return image
	 */
	public String getImage() {
		return image;
	}

	/**
	 * 
	 * @param image
	 *            to set image
	 */
	public void setImage(String image) {
		this.image = image;
	}

	/**
	 * 
	 * @return format
	 */
	public String getFormat() {
		return format;
	}

	/**
	 * 
	 * @param format
	 *            to set format
	 */
	public void setFormat(String format) {
		this.format = format;
	}

	/**
	 * 
	 * @return timeStamp
	 */
	public OffsetDateTime getTimeStamp() {
		return timeStamp;
	}

	/**
	 * 
	 * @param timeStamp
	 *            to set timeStamp
	 */
	public void setTimeStamp(OffsetDateTime timeStamp) {
		this.timeStamp = timeStamp;
	}

}
