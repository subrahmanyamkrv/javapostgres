/**
 * 
 */
package com.oati.evms.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.oati.evms.model.ElectricVehicle;
import com.oati.evms.repository.ElectricVehicleRepository;

/**
 * This class is used to parse and save EV details to MongoDB
 * 
 * @author raghavendrar
 *
 */
@Service
public class ElectricVehicleServiceImpl implements ElectricVehicleService {

	private static final Logger logger = Logger.getLogger(ElectricVehicleServiceImpl.class);
	/**
	 * used to get electric vehicles from MongoDB
	 */
	@Autowired
	ElectricVehicleRepository electricVehicleRepository;

	/**
	 * used to buid electric vehicle object and save to MongoDb
	 */
	@Override
	public void BuildElectricVehicles(String inputPath, String outputPath) {

		logger.info("ElectricVehicleServiceImpl :: BuildElectricVehicles() inputPath :: " + inputPath + "  outputPath"
				+ outputPath);

		final File directory = new File(inputPath);
		File[] filesList = directory.listFiles();
		if (filesList != null) {
			for (File file : filesList) {
				if (file.isFile()) {
					BufferedReader reader = null;
					// open file input stream
					try {
						reader = new BufferedReader(new FileReader(file.getAbsolutePath()));
					} catch (FileNotFoundException exception) {
						logger.error("ElectricVehicleServiceImpl :: BuildElectricVehicles() " + exception);
					}
					// read file line by line
					String line = null;
					Scanner scanner = null;
					int index = 0;
					List<ElectricVehicle> evs = new ArrayList<>();
					try {
						String header = reader.readLine();
						while ((line = reader.readLine()) != null) {

							ElectricVehicle ev = new ElectricVehicle();
							scanner = new Scanner(line);
							scanner.useDelimiter(",");

							while (scanner.hasNext()) {
								String data = scanner.next();

								if (index == 0)
									ev.setMake(data);
								else if (index == 1)
									ev.setModel(data);
								else if (index == 2)
									ev.setYear(data);
								else if (index == 3)
									ev.setColor(data);
								else if (index == 4)
									ev.setBatteryCapacity(data);
								else if (index == 5)
									ev.setPlugType(data);
								else if (index == 6)
									ev.setStyle(data);
								else if (index == 7)
									ev.setRange(data);
								else if (index == 8)
									ev.setHomeChargingSpeed(data);
								else if (index == 9)
									ev.setFastChargingTime(data);
								else if (index == 10)
									ev.setFastChargingThreshold(data);

								else
									logger.info("ElectricVehicleServiceImpl :: BuildElectricVehicles() invalid data::"
											+ data);
								index++;
							}
							index = 0;
							String vehicleId = ev.getMake() + "_" + ev.getModel() + "_" + ev.getYear();
							ElectricVehicle existingVehicle = null;
							try {
								existingVehicle = electricVehicleRepository.findVehicleById(vehicleId);
							} catch (Exception exception) {
								logger.error("ElectricVehicleServiceImpl :: BuildElectricVehicles() exception :: "
										+ exception);
							}
							if (existingVehicle != null) {

								logger.info(
										"ElectricVehicleServiceImpl :: BuildElectricVehicles() existingVehicle != null");
								existingVehicle.setId(existingVehicle.getId());
								existingVehicle.setMake(ev.getMake());
								existingVehicle.setModel(ev.getModel());
								existingVehicle.setYear(ev.getYear());
								existingVehicle.setPlugType(ev.getPlugType());
								existingVehicle.setStyle(ev.getStyle());
								existingVehicle.setColor(ev.getColor());
								existingVehicle.setBatteryCapacity(ev.getBatteryCapacity());

								evs.add(existingVehicle);
							}
							if (existingVehicle == null) {
								logger.info(
										"ElectricVehicleServiceImpl :: BuildElectricVehicles() existingVehicle == null");
								ev.setVehicleId(vehicleId);
								evs.add(ev);
							}
						}
						reader.close();
						try {
							electricVehicleRepository.saveAll(evs);
						} catch (Exception exception) {
							logger.error(
									"ElectricVehicleServiceImpl :: BuildElectricVehicles() exception for saveAll(evs)  :: "
											+ exception);
						}
						file.renameTo(new File(outputPath + file.getName()));
					} catch (Exception exception) {
						logger.error("ElectricVehicleServiceImpl :: BuildElectricVehicles() exception :: " + exception);
					}

				}
			}
		}

	}

}
