package com.oati.evms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongoImageBuilderApplication {

	public static void main(String[] args) {
		SpringApplication.run(MongoImageBuilderApplication.class, args);
	}

}

