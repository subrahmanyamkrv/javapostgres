package com.oati.evms.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.oati.evms.service.ElectricVehicleService;
import com.oati.evms.service.ImageService;

@RestController
@RequestMapping("/Seeder")
public class SeedController {

	private static final Logger seedControllerLogger = Logger.getLogger(SeedController.class);
	/**
	 * to get the image service
	 */
	@Autowired
	ImageService imageService;
	/**
	 * to get the ElectricVehicleService service
	 */
	@Autowired
	ElectricVehicleService electricVehicleService;

	/**
	 * Used to save the Image in MongoDB
	 * 
	 * @param inputPath
	 *            input path of images directory
	 * @param outputPath
	 *            output path of images directory
	 */
	@PostMapping("/SaveImage")
	public void saveImage(@RequestParam(value = "inputPath") String inputPath,
			@RequestParam(value = "outputPath") String outputPath) {
		seedControllerLogger.info("SeedController :: saveImage() method entered with  inputPath :: " + inputPath
				+ "outputPath :: " + outputPath);
		imageService.ImageBuilder(inputPath, outputPath);
	}

	/**
	 * Used to save the electric vehicles in MongoDB
	 * 
	 * @param inputPath
	 * @param outputPath
	 */
	@PostMapping("/SaveEVModels")
	public void saveEVModles(@RequestParam(value = "inputPath") String inputPath,
			@RequestParam(value = "outputPath") String outputPath) {
		seedControllerLogger.info("SeedController :: saveImage() method entered with  inputPath :: " + inputPath
				+ "outputPath :: " + outputPath);

		electricVehicleService.BuildElectricVehicles(inputPath, outputPath);
	}
}
