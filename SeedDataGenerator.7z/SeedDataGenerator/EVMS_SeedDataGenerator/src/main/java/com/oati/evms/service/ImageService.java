package com.oati.evms.service;

import org.springframework.stereotype.Service;

@Service
public interface ImageService {
	/**
	 * Used to buid the image
	 * 
	 * @param inputPath
	 * @param outputPath
	 */
	public void ImageBuilder(String inputPath, String outputPath);

}
