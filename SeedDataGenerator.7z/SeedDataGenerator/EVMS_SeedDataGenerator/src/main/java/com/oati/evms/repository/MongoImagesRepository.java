package com.oati.evms.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.oati.evms.model.MongoImage;

/**
 * Used to get the images data from MongoDB
 * 
 * @author venkatas
 *
 */
@Repository
public interface MongoImagesRepository extends MongoRepository<MongoImage, String> {

}
