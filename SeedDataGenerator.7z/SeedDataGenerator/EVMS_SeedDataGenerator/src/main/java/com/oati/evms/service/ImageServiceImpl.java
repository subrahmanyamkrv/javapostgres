
package com.oati.evms.service;

import java.io.File;
import java.io.IOException;
import java.util.Base64;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.threeten.bp.OffsetDateTime;

import com.oati.evms.model.MongoImage;
import com.oati.evms.repository.MongoImagesRepository;
import com.oati.evms.util.FileUtil;

@Service
public class ImageServiceImpl implements ImageService {

	private static final Logger ImageServiceImplLogger = Logger.getLogger(ImageServiceImpl.class);
	/**
	 * used to get Image details from MongoDb
	 */
	@Autowired
	MongoImagesRepository mongoImagesRepository;

	/**
	 * Used to build the directory path for input and output
	 */
	@Override
	public void ImageBuilder(String inputpath, String outputpath) {
		ImageServiceImplLogger.info("ImageServiceImpl :: ImageBuilder() method entered with inputpath :: " + inputpath
				+ "  outputpath :: " + outputpath);

		if (FileUtil.isWindows()) {
			ImageServiceImplLogger.info("ImageServiceImpl :: ImageBuilder() method FileUtil.isWindows() ");
			String inputPath = inputpath;
			String outputPath = outputpath;

			String stationFullImageInputPath = inputPath + "station\\full\\";
			String stationFullImageOutputPath = outputPath + "station\\full\\";

			decodeImage(stationFullImageInputPath, stationFullImageOutputPath, "station", "full");

			String stationTBImageInputPath = inputPath + "station\\thumbnail\\";
			String stationTBImageOutputPath = outputPath + "station\\thumbnail\\";

			decodeImage(stationTBImageInputPath, stationTBImageOutputPath, "station", "thumbnail");

			String chargerFullImageInputPath = inputPath + "charger\\full\\";
			String chargerFullImageOutputPath = outputPath + "charger\\full\\";

			decodeImage(chargerFullImageInputPath, chargerFullImageOutputPath, "charger", "full");

			String chargerTBImageInputPath = inputPath + "charger\\thumbnail\\";
			String chargerTBImageOutputPath = outputPath + "charger\\thumbnail\\";

			decodeImage(chargerTBImageInputPath, chargerTBImageOutputPath, "charger", "thumbnail");

			String userFullImageInputPath = inputPath + "user\\full\\";
			String userFullImageOutputPath = outputPath + "user\\full\\";

			decodeImage(userFullImageInputPath, userFullImageOutputPath, "user", "full");

			String userTBImageInputPath = inputPath + "user\\thumbnail\\";
			String userTBImageOutputPath = outputPath + "user\\thumbnail\\";

			decodeImage(userTBImageInputPath, userTBImageOutputPath, "user", "thumbnail");

			String vehicleFullImageInputPath = inputPath + "vehicle\\full\\";
			String vehicleFullImageOutputPath = outputPath + "vehicle\\full\\";
			decodeImage(vehicleFullImageInputPath, vehicleFullImageOutputPath, "vehicle", "full");

			String vehicleTBImageInputPath = inputPath + "vehicle\\thumbnail\\";
			String vehicleTBImageOutputPath = outputPath + "vehicle\\thumbnail\\";
			decodeImage(vehicleTBImageInputPath, vehicleTBImageOutputPath, "vehicle", "thumbnail");
		}

		if (FileUtil.isUnix()) {
			ImageServiceImplLogger.info("ImageServiceImpl :: ImageBuilder() method FileUtil.isUnix() ");

			String inputPath = inputpath;
			String outputPath = outputpath;

			String stationFullImageInputPath = inputPath + "station/full/";
			String stationFullImageOutputPath = outputPath + "station/full/";

			decodeImage(stationFullImageInputPath, stationFullImageOutputPath, "station", "full");

			String stationTBImageInputPath = inputPath + "station/thumbnail/";
			String stationTBImageOutputPath = outputPath + "station/thumbnail/";

			decodeImage(stationTBImageInputPath, stationTBImageOutputPath, "station", "thumbnail");

			String chargerFullImageInputPath = inputPath + "charger/full/";
			String chargerFullImageOutputPath = outputPath + "charger/full/";

			decodeImage(chargerFullImageInputPath, chargerFullImageOutputPath, "charger", "full");

			String chargerTBImageInputPath = inputPath + "charger/thumbnail/";
			String chargerTBImageOutputPath = outputPath + "charger/thumbnail/";

			decodeImage(chargerTBImageInputPath, chargerTBImageOutputPath, "charger", "thumbnail");

			String userFullImageInputPath = inputPath + "user/full/";
			String userFullImageOutputPath = outputPath + "user/full/";

			decodeImage(userFullImageInputPath, userFullImageOutputPath, "user", "full");

			String userTBImageInputPath = inputPath + "user/thumbnail/";
			String userTBImageOutputPath = outputPath + "user/thumbnail/";

			decodeImage(userTBImageInputPath, userTBImageOutputPath, "user", "thumbnail");

			String vehicleFullImageInputPath = inputPath + "vehicle/full/";
			String vehicleFullImageOutputPath = outputPath + "vehicle/full/";
			decodeImage(vehicleFullImageInputPath, vehicleFullImageOutputPath, "vehicle", "full");

			String vehicleTBImageInputPath = inputPath + "vehicle/thumbnail/";
			String vehicleTBImageOutputPath = outputPath + "vehicle/thumbnail/";
			decodeImage(vehicleTBImageInputPath, vehicleTBImageOutputPath, "vehicle", "thumbnail");
		}
		ImageServiceImplLogger.info("ImageServiceImpl :: ImageBuilder() method end");
	}

	/**
	 * {@inheritDoc} This method is used to decode the image or file content
	 * 
	 * @param inputPath
	 * @param outputPath
	 * @param objectType
	 * @param ImageType
	 */
	public void decodeImage(String inputPath, String outputPath, String objectType, String ImageType) {
		ImageServiceImplLogger.info("ImageServiceImpl :: decodeImage method entered with inputPath :: " + inputPath
				+ " outputPath :: " + outputPath + " objectType ::  " + objectType + "ImageType :: " + ImageType);
		final File directory = new File(inputPath);
		File[] filesList = directory.listFiles();
		if (filesList != null) {
			for (File file : filesList) {
				if (file.isFile()) {
					String filePath = file.getAbsolutePath();
					byte[] fileContent = null;
					try {
						fileContent = FileUtils.readFileToByteArray(new File(filePath));
					} catch (IOException e) {
						ImageServiceImplLogger.error("ImageServiceImpl :: decodeImage() exception ::" + e);
					}
					String encodedStringImage = Base64.getEncoder().encodeToString(fileContent);
					dumpImageToMongo(file, encodedStringImage, objectType, ImageType);
					file.renameTo(new File(outputPath + file.getName()));
					ImageServiceImplLogger.info(
							"ImageServiceImpl :: decodeImage method file moved to ::  " + outputPath + file.getName());
				}
			}
		} // if (fList != null)
		ImageServiceImplLogger.info("ImageServiceImpl :: decodeImage method end");
	}

	/**
	 * This method is used to save the image to MongoDB
	 * 
	 * @param inputFile
	 * @param encodedImage
	 * @param objectType
	 * @param ImageType
	 */
	public void dumpImageToMongo(File inputFile, String encodedImage, String objectType, String ImageType) {
		ImageServiceImplLogger.info("ImageServiceImpl :: dumpImageToMongo() entered ");
		String fileName = inputFile.getName();
		String objectId = FilenameUtils.removeExtension(fileName);

		String objecttype = objectType;
		String imagetype = ImageType;
		String image = encodedImage;

		String format = FilenameUtils.getExtension(inputFile.getAbsolutePath());
		MongoImage mongoImage = new MongoImage();
		mongoImage.setObjectId(objectId);
		mongoImage.setObjecttype(objecttype);
		mongoImage.setImagetype(imagetype);
		mongoImage.setImage(image);
		mongoImage.setFormat(format);
		OffsetDateTime timeStamp = OffsetDateTime.now();
		mongoImage.setTimeStamp(timeStamp);

		try {
			mongoImagesRepository.save(mongoImage);
			ImageServiceImplLogger.info("ImageServiceImpl :: dumpImageToMongo() file saved to MongoDB ");
		} catch (Exception e) {
			ImageServiceImplLogger.error("ImageServiceImpl :: dumpImageToMongo() exception :: " + e);
		}
		ImageServiceImplLogger.info("ImageServiceImpl :: dumpImageToMongo() entered ");
	}

}
